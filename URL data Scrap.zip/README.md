
# Real-time Web Scraper with Dashboard

This project scrapes data from a list of URLs (10,000+) and displays results in real-time inside Google Colab.

## Features
- Asynchronous scraping (aiohttp)
- Respects robots.txt
- Extracts title, meta description, first <h1>, status
- Saves results incrementally to CSV
- Real-time dashboard (last 10 entries shown live)

## Usage
1. Upload your `urls.txt` file (one URL per line) into Colab.
2. Run the notebook step by step.
3. Results will appear live and be saved to `results.csv`.

## Installation
Install dependencies in Colab:
```bash
pip install -r requirements.txt
```

## Notes
- Please respect target sites’ robots.txt and rate limits.
- For deployment outside Colab, you can adapt the code to Streamlit/Dash.
